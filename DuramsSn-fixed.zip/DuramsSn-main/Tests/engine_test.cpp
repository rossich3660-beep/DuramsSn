#include "../SnareEngine.h"
#include <random>
#include <cstdio>
using namespace durams;
int main(){
  std::mt19937 g(1); auto U=[&](double a,double b){return std::uniform_real_distribution<double>(a,b)(g);};
  const double srs[]={8000,22050,44100,48000,96000,192000};
  const int blocks[]={1,7,32,64,127,512,1024,4096};
  long long checks=0;
  for(int iter=0;iter<300;++iter){
    SnareEngine e; double sr=srs[g()%6]; e.prepare(sr);
    SampleData s; s.sampleRate=srs[g()%6];
    int len = (iter%10==0)?2:(int)U(2,200000);
    s.left.resize(len); s.right.resize(len);
    for(int i=0;i<len;++i){s.left[i]=(float)U(-1,1);s.right[i]=(float)U(-1,1);}
    e.setSample(&s);
    for(int b=0;b<400;++b){
      Params p; p.level=(float)U(-36,12);p.curve=(float)U(-1,1);p.range=(float)U(0,1);p.tone=(float)U(-1,1);
      p.bright=(float)U(0,1);p.human=(float)U(0,1);p.pitch=(float)U(-12,12);p.snap=(float)U(0,1);
      p.decay=(float)U(0,1);p.wires=(float)U(0,1);p.body=(float)U(0,1);p.drive=(float)U(0,1);
      e.setParams(p);
      int n=blocks[g()%8]; std::vector<float> L(n,0),R(n,0);
      int k=g()%4; for(int j=0;j<k;++j) e.noteOn((float)U(0,1));
      if(g()%50==0) e.allNotesOff();
      e.render(L.data(),R.data(),n);
      for(int i=0;i<n;++i){ if(!std::isfinite(L[i])||!std::isfinite(R[i])||std::fabs(L[i])>4.001f){printf("BAD sample\n");return 1;} ++checks;}
    }
  }
  printf("OK %lld samples, no ASan/UBSan errors\n",checks);
}
